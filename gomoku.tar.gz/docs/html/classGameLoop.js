var classGameLoop =
[
    [ "GameLoop", "classGameLoop.html#a1b3a349263c8c243400c8cc8fe718655", null ],
    [ "~GameLoop", "classGameLoop.html#ae6c558d0d751a068dbafe2cae465ec1f", null ],
    [ "continueGame", "classGameLoop.html#adc88e75cb8106655d88296cc082767bc", null ],
    [ "end", "classGameLoop.html#a30733a30b29bc93c3009b62bde59ddde", null ],
    [ "isNumber", "classGameLoop.html#aef095ed6895919ae55e260b0149ff29a", null ],
    [ "play", "classGameLoop.html#a7e143e66d9a047a15d20c20da85f23d0", null ],
    [ "startNew", "classGameLoop.html#a12718de4b3e9535288cc77c8d5f27979", null ],
    [ "board", "classGameLoop.html#a73ffb8954f2f2fd298e2bfe22be73ce6", null ],
    [ "drawer", "classGameLoop.html#a9f25ffc0e91f10c6030ca6b05032f71f", null ],
    [ "stillPlaying", "classGameLoop.html#a74bff510eaf3cab91599f164dfa903cf", null ]
];