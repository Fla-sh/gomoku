var classLogger =
[
    [ "Logger", "classLogger.html#abc41bfb031d896170c7675fa96a6b30c", null ],
    [ "getPrompt", "classLogger.html#a4004f551a3c44ceb479c7c36e4e1dee8", null ],
    [ "now", "classLogger.html#a756a608050fea9f497dd2736f9321f3b", null ],
    [ "purgeMoveLog", "classLogger.html#a69ca833f3e3643333d718f0cce464f9b", null ],
    [ "safeEvent", "classLogger.html#ad2156c976610010c579352c9aeb4b388", null ],
    [ "saveMove", "classLogger.html#a1e920507694b06e8a16120783902e229", null ],
    [ "prompt", "classLogger.html#a80c00c4446e4310cfbf9ed048edbe979", null ]
];