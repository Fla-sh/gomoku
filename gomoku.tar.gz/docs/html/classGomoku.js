var classGomoku =
[
    [ "Gomoku", "classGomoku.html#a1265604f3895564bc858dda5a7085117", null ]
];