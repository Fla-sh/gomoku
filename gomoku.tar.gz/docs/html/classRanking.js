var classRanking =
[
    [ "Ranking", "classRanking.html#a7b1142b455d06f3d455d796ed329118f", null ],
    [ "add", "classRanking.html#a4969110ba50a492be5d125c9b1710cf0", null ],
    [ "display", "classRanking.html#ade50abc368e58d4c7879e437f819e982", null ],
    [ "now", "classRanking.html#aa3ed270c7a8a059568c3af87fd73bd03", null ],
    [ "sort", "classRanking.html#aa77c088257f2ac17f165147283136016", null ],
    [ "ranking", "classRanking.html#aead444bd691bbfa450ccdec64012ab86", null ]
];