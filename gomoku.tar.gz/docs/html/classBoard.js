var classBoard =
[
    [ "Board", "classBoard.html#a9ee491d4fea680cf69b033374a9fdfcb", null ],
    [ "delinearise", "classBoard.html#a58de3d2bd69db7ef9258b3b907eb9de8", null ],
    [ "findDiagonal", "classBoard.html#a99cff26f921e228dc11c381747381ced", null ],
    [ "findHorizontal", "classBoard.html#a2f984f83124db1b1df386ef9deff6a24", null ],
    [ "findVertical", "classBoard.html#a4ee8b912055e8705e37a9b37125b70f0", null ],
    [ "getField", "classBoard.html#a2e57d7f5e62b0d870fb3ff1b76eb18ba", null ],
    [ "getPlayer", "classBoard.html#ad4322f41e87c8a8a99e3424fb2a2a1ec", null ],
    [ "getTotalMoves", "classBoard.html#aedc0672dfb6bddabc1c1cf091b483cbb", null ],
    [ "getWinner", "classBoard.html#adef3bc4bb22a2f54b7703ceff15aea5b", null ],
    [ "isGameEnded", "classBoard.html#afadc1ddff22c3a2ee25cad41ed7e5da0", null ],
    [ "linearise", "classBoard.html#a17ee7e0130537721b492cb7ed7235974", null ],
    [ "move", "classBoard.html#a5ee56f4407f7792fe6f134a59d4af190", null ],
    [ "recreate", "classBoard.html#aadae139aa7b1d53e7f9ae0ae0768f417", null ],
    [ "save", "classBoard.html#afc8625b4719496080a988c294869d56a", null ],
    [ "board", "classBoard.html#af588c465a63e9447a674398ec44446a9", null ],
    [ "currentPlayer", "classBoard.html#a86b952cc745c2bd392f74434653457d3", null ],
    [ "madeMoves", "classBoard.html#abfd418c2974974039da3fff24ad5c185", null ],
    [ "winner", "classBoard.html#a67eeec840d17ab997e32234493ac7e39", null ]
];