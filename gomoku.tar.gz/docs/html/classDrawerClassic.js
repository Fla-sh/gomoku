var classDrawerClassic =
[
    [ "draw", "classDrawerClassic.html#ab5e18d90571afab9a2b8482b2d9d8264", null ],
    [ "EmptyMark", "classDrawerClassic.html#a9d79d07a7b0d24a5c8cd3bbfb4e60d44", null ],
    [ "OMark", "classDrawerClassic.html#a5f1c89c7c6d37eb435f447f1a5934e2b", null ],
    [ "XMark", "classDrawerClassic.html#a31aba72f2a6463a1ad4a6974c31b65ae", null ]
];