var hierarchy =
[
    [ "Board", "classBoard.html", null ],
    [ "Drawer", "classDrawer.html", [
      [ "DrawerAlternative", "classDrawerAlternative.html", null ],
      [ "DrawerClassic", "classDrawerClassic.html", null ],
      [ "DrawerMess", "classDrawerMess.html", null ]
    ] ],
    [ "GameLoop", "classGameLoop.html", null ],
    [ "Gomoku", "classGomoku.html", null ],
    [ "Logger", "classLogger.html", null ],
    [ "Menu", "classMenu.html", [
      [ "MainMenu", "classMainMenu.html", null ]
    ] ],
    [ "Ranking", "classRanking.html", null ]
];