var classDrawerAlternative =
[
    [ "draw", "classDrawerAlternative.html#a2d56b61df9a3878c9aa24db5896578ba", null ],
    [ "EmptyMark", "classDrawerAlternative.html#a11d00e3321f98034af61d70f570b19aa", null ],
    [ "OMark", "classDrawerAlternative.html#a4f80da586b01bab01119d2a76fe39a95", null ],
    [ "XMark", "classDrawerAlternative.html#a58688e22709b37e5fdcf4ce5d5a73b96", null ]
];