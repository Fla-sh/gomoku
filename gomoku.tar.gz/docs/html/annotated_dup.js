var annotated_dup =
[
    [ "Board", "classBoard.html", "classBoard" ],
    [ "Drawer", "classDrawer.html", "classDrawer" ],
    [ "DrawerAlternative", "classDrawerAlternative.html", "classDrawerAlternative" ],
    [ "DrawerClassic", "classDrawerClassic.html", "classDrawerClassic" ],
    [ "DrawerMess", "classDrawerMess.html", "classDrawerMess" ],
    [ "GameLoop", "classGameLoop.html", "classGameLoop" ],
    [ "Gomoku", "classGomoku.html", "classGomoku" ],
    [ "Logger", "classLogger.html", "classLogger" ],
    [ "MainMenu", "classMainMenu.html", "classMainMenu" ],
    [ "Menu", "classMenu.html", "classMenu" ],
    [ "Ranking", "classRanking.html", "classRanking" ]
];