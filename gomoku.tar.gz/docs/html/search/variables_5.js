var searchData=
[
  ['ranking',['ranking',['../classRanking.html#aead444bd691bbfa450ccdec64012ab86',1,'Ranking']]]
];
