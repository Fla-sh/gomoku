var searchData=
[
  ['safeevent',['safeEvent',['../classLogger.html#ad2156c976610010c579352c9aeb4b388',1,'Logger']]],
  ['save',['save',['../classBoard.html#afc8625b4719496080a988c294869d56a',1,'Board']]],
  ['savemove',['saveMove',['../classLogger.html#a1e920507694b06e8a16120783902e229',1,'Logger']]],
  ['sort',['sort',['../classRanking.html#aa77c088257f2ac17f165147283136016',1,'Ranking']]],
  ['startnew',['startNew',['../classGameLoop.html#a12718de4b3e9535288cc77c8d5f27979',1,'GameLoop']]],
  ['stillplaying',['stillPlaying',['../classGameLoop.html#a74bff510eaf3cab91599f164dfa903cf',1,'GameLoop']]]
];
