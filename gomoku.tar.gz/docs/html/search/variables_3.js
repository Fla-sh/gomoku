var searchData=
[
  ['mademoves',['madeMoves',['../classBoard.html#abfd418c2974974039da3fff24ad5c185',1,'Board']]]
];
