var searchData=
[
  ['finddiagonal',['findDiagonal',['../classBoard.html#a99cff26f921e228dc11c381747381ced',1,'Board']]],
  ['findhorizontal',['findHorizontal',['../classBoard.html#a2f984f83124db1b1df386ef9deff6a24',1,'Board']]],
  ['findvertical',['findVertical',['../classBoard.html#a4ee8b912055e8705e37a9b37125b70f0',1,'Board']]]
];
