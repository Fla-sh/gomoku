var searchData=
[
  ['now',['now',['../classLogger.html#a756a608050fea9f497dd2736f9321f3b',1,'Logger::now()'],['../classRanking.html#aa3ed270c7a8a059568c3af87fd73bd03',1,'Ranking::now()']]]
];
