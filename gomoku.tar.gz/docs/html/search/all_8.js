var searchData=
[
  ['linearise',['linearise',['../classBoard.html#a17ee7e0130537721b492cb7ed7235974',1,'Board']]],
  ['logger',['Logger',['../classLogger.html',1,'']]]
];
