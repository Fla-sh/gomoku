var searchData=
[
  ['add',['add',['../classRanking.html#a4969110ba50a492be5d125c9b1710cf0',1,'Ranking']]]
];
