var searchData=
[
  ['logger',['Logger',['../classLogger.html',1,'']]]
];
