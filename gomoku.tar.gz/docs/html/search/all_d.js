var searchData=
[
  ['ranking',['Ranking',['../classRanking.html',1,'Ranking'],['../classRanking.html#aead444bd691bbfa450ccdec64012ab86',1,'Ranking::ranking()']]],
  ['recreate',['recreate',['../classBoard.html#aadae139aa7b1d53e7f9ae0ae0768f417',1,'Board']]]
];
