var searchData=
[
  ['gameloop',['GameLoop',['../classGameLoop.html',1,'']]],
  ['getfield',['getField',['../classBoard.html#a2e57d7f5e62b0d870fb3ff1b76eb18ba',1,'Board']]],
  ['getplayer',['getPlayer',['../classBoard.html#ad4322f41e87c8a8a99e3424fb2a2a1ec',1,'Board']]],
  ['getprompt',['getPrompt',['../classLogger.html#a4004f551a3c44ceb479c7c36e4e1dee8',1,'Logger']]],
  ['gettotalmoves',['getTotalMoves',['../classBoard.html#aedc0672dfb6bddabc1c1cf091b483cbb',1,'Board']]],
  ['getwinner',['getWinner',['../classBoard.html#adef3bc4bb22a2f54b7703ceff15aea5b',1,'Board']]],
  ['gomoku',['Gomoku',['../classGomoku.html',1,'']]]
];
