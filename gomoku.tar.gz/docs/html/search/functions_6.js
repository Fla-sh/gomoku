var searchData=
[
  ['isgameended',['isGameEnded',['../classBoard.html#afadc1ddff22c3a2ee25cad41ed7e5da0',1,'Board']]],
  ['isnumber',['isNumber',['../classGameLoop.html#aef095ed6895919ae55e260b0149ff29a',1,'GameLoop']]]
];
