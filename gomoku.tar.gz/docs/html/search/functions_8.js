var searchData=
[
  ['move',['move',['../classBoard.html#a5ee56f4407f7792fe6f134a59d4af190',1,'Board']]]
];
