var searchData=
[
  ['currentplayer',['currentPlayer',['../classBoard.html#a86b952cc745c2bd392f74434653457d3',1,'Board']]]
];
