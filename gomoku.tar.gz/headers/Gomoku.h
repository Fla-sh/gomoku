//
// Created by piotr on 14.10.19.
//

#ifndef GOMOKU_GOMOKU_H
#define GOMOKU_GOMOKU_H

/**
 * Program main loop
 */
class Gomoku {
public:
    Gomoku();
};


#endif //GOMOKU_GOMOKU_H
