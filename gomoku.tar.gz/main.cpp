#include <iostream>
#include "headers/Gomoku.h"
#include "classes/Gomoku.cpp"

int main() {
    Gomoku gomoku;
    return 0;
}